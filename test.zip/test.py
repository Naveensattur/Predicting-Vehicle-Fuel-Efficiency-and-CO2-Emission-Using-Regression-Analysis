from flask import Flask, render_template, request, jsonify
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
import os

app = Flask(__name__)

# Load dataset
file_path = 'Fuel_Consumption_2000-2022.csv'
data = pd.read_csv(file_path)

# Preprocess data
numeric_columns = ['ENGINE SIZE', 'CYLINDERS', 'FUEL CONSUMPTION',
                   'HWY (L/100 km)', 'COMB (L/100 km)', 'COMB (mpg)', 'EMISSIONS']
data[numeric_columns] = data[numeric_columns].apply(pd.to_numeric, errors='coerce')
data_cleaned = data.dropna(subset=numeric_columns)

X = data_cleaned[['ENGINE SIZE', 'CYLINDERS', 'FUEL CONSUMPTION', 'COMB (L/100 km)']]
y = data_cleaned['EMISSIONS']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train models
lr = LinearRegression()
lr.fit(X_train, y_train)

rf = RandomForestRegressor(random_state=42)
rf.fit(X_train, y_train)

gbr = GradientBoostingRegressor(random_state=42)
gbr.fit(X_train, y_train)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    engine_size = float(data['engine_size'])
    cylinders = int(data['cylinders'])
    fuel_consumption = float(data['fuel_consumption'])
    comb_l_per_km = float(data['comb_l_per_km'])

    input_data = pd.DataFrame({
        'ENGINE SIZE': [engine_size],
        'CYLINDERS': [cylinders],
        'FUEL CONSUMPTION': [fuel_consumption],
        'COMB (L/100 km)': [comb_l_per_km]
    })

    lr_prediction = lr.predict(input_data)[0]
    rf_prediction = rf.predict(input_data)[0]
    gbr_prediction = gbr.predict(input_data)[0]

    final_fuel_consumption = fuel_consumption * (1 + (0.1 * (engine_size - 2)))

    result = {
        "Linear Regression": lr_prediction,
        "Random Forest": rf_prediction,
        "Gradient Boosting": gbr_prediction,
        "Fuel Consumption (L/100 km)": final_fuel_consumption
    }
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True)
